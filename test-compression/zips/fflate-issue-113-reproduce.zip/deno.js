import * as fflate from "https://cdn.skypack.dev/fflate?min";

const { ZipDeflate, Zip, ZipPassThrough } = fflate;

function getFileListDeno() {
  const items = Deno.readDirSync(Deno.cwd());
  const filenames = Array.from(items)
    .filter(
      (item) =>
        item.isDirectory === false &&
        !item.name.endsWith(".js") &&
        !item.name.endsWith(".zip")
    )
    .map((item) => item.name);
  return filenames;
}

function readFilenames() {
  const buffer = Deno.readFileSync(`${Deno.cwd()}/filenames.json`);
  const decoder = new TextDecoder("utf-8");
  const data = decoder.decode(buffer);
  const json = JSON.parse(data);
  return json;
}

function getFileList() {
  let filenames;
  try {
    filenames = readFilenames();
  } catch (error) {
    console.error(error);
    filenames = getFileListDeno();
    const f = Deno.openSync(`${Deno.cwd()}/filenames.json`, {
      read: true,
      write: true,
      createNew: true,
    });
    const jsonText = JSON.stringify(filenames);
    f.writeSync(new TextEncoder("utf-8").encode(jsonText));
    f.close();
  }
  return filenames;
}

function getChunk(filename) {
  const path = `${Deno.cwd()}/${filename}`;
  const chunk = Deno.readFileSync(path);
  return chunk;
}

(async () => {
  const zipPath = `${Deno.cwd()}/test.zip`;
  try {
    await Deno.remove(zipPath);
  } catch (error) {
    console.error(error);
  }
  const file = await Deno.open(zipPath, {
    read: true,
    write: true,
    createNew: true,
  });
  const tyepBlob = true;
  const zipOut = [];
  async function finishHandle() {
    const blob = new Blob(zipOut, { type: "application/zip" });
    const buffer = await blob.arrayBuffer();
    file.writeSync(new Uint8Array(buffer));
    file.close();
  }
  const savedZip = new Zip((err, dat, final) => {
    if (err) {
      console.error(err);
      throw err;
    }
    if (tyepBlob) {
      zipOut.push(dat);
    } else {
      file.writeSync(dat);
    }

    if (final) {
      if (tyepBlob) {
        finishHandle();
      } else {
        file.close();
      }
      console.log("finish!");
    }
  });

  const filenames = getFileList();
  for (const filename of filenames) {
    console.log(filename);
    const chunk = getChunk(filename);
    if (filename.endsWith("jpeg") || filename.endsWith("jpg")) {
      const nonStreamingFile = new ZipPassThrough(filename);
      savedZip.add(nonStreamingFile);
      nonStreamingFile.push(chunk, true);
    } else {
      const nonStreamingFile = new ZipDeflate(filename, {
        level: 9,
      });
      savedZip.add(nonStreamingFile);
      nonStreamingFile.push(chunk, true);
    }
  }

  savedZip.end();
})();
